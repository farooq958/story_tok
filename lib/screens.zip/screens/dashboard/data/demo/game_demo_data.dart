var gameData = [
  {
    "id": "1",
    "video_title": "Video 1",
    "url":
        "https://firebasestorage.googleapis.com/v0/b/videostreaming-test.appspot.com/o/vid%2FSnaptik_6745671851688692998_tiktok.mp4?alt=media&token=e6c76be2-9d8e-4be6-aedc-89ddd4985871",
    "comments": "150",
    "likes": "223",
    "song_name": "Song 1 - Artist 1",
    "user": "User 1",
    "user_pic":
        "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg-1024x683.jpg"
  },
  {
    "id": "2",
    "video_title": "Firestore",
    "url":
        "https://firebasestorage.googleapis.com/v0/b/videostreaming-test.appspot.com/o/vid%2FSnaptik_6842407707551599878_carlos-barrios%20(1).mp4?alt=media&token=965f5080-2771-4477-bd9d-defc7b581c5d",
    "comments": "143",
    "likes": "523",
    "song_name": "Test Song 2",
    "user": "User 4",
    "user_pic":
        "https://i.pinimg.com/originals/5e/eb/8d/5eeb8d615bea040425f9937699392751.jpg"
  },
];