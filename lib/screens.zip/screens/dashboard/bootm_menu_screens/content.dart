import 'package:flutter/material.dart';


class AddContentPage extends StatefulWidget {
  const AddContentPage({Key? key}) : super(key: key);

  @override
  State<AddContentPage> createState() => _AddContentPageState();
}

class _AddContentPageState extends State<AddContentPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
    child: Column(children: [ 
      //
      Text("AddContentPage")
     ],),
    );
  }
}